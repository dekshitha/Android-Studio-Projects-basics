package com.example.cc_coroutine

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import kotlinx.coroutines.*

class MainActivity : AppCompatActivity() {
    private var count = 0
    private lateinit var msgtv:TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val textView = findViewById<TextView>(R.id.tvCount)
        msgtv=findViewById(R.id.tvMessage)
        val countButton = findViewById<Button>(R.id.btnCount)
        val downloadButton = findViewById<Button>(R.id.btnDownload)

        countButton.setOnClickListener {
            textView.text = count++.toString()
        }
        downloadButton.setOnClickListener {
            CoroutineScope(Dispatchers.IO).launch {
                downloadUserData()
            }
            //coroutine scope->interface to track coroutine nd handle res leak
            //dispatchers.main->ui thread(small tasks)
            //.io->backgrnd thread local db,files
            //.default->intensive tasks, huge list
            //.unconfined->global scope
            //coroutine builder->launch (returns job inst, doesnt return value),async(launches parallel coroutine, get value-await()),produce(stream of ele),runlocking(fr testing)

        }
    }
    private suspend fun downloadUserData() {
        for (i in 1..200000) {
            Log.i("MyTag", "Downloading user $i in ${Thread.currentThread().name}")
            //msgtv.text="Downloading user $i" //error as background thread cant access ui, need to change thread

            //suspending functs-withcontext,delay,join (can be called in coroutine only)
            withContext(Dispatchers.Main){
                msgtv.text="downloading user $i"
            }

            delay(100)
            //main thread->ui tasks,taking input
            //for using delay funct should hv suspend
        }
    }
}

