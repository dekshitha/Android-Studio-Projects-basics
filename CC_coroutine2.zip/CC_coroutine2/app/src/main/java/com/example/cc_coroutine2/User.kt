package com.example.cc_coroutine2

data class User(val id:Int,val name:String)
