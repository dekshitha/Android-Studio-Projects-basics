package com.example.cc_coroutine2

import kotlinx.coroutines.delay

class UserRepo {
    //list of obj nd return
    suspend fun getUsers():List<User>{
        delay(8000)
        val users: List<User> = listOf(
            User(1,"Sam"),
            User(2,"Ram"),
            User(3,"tom"),
            User(4,"Ram"),
            User(5,"Ram"),
            User(6,"Ram"),
            User(7,"Ram"),


        )
        return users
    }
}