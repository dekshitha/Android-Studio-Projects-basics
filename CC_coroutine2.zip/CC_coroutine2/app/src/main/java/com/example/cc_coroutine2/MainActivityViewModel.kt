package com.example.cc_coroutine2

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivityViewModel:ViewModel() {
    private var userRepo=UserRepo()
    var users : MutableLiveData<List<User>?> = MutableLiveData()

    fun getUserData(){
        viewModelScope.launch {
            //extension of view model to cancel job out of viewmodel, avoids res leak(automatically canceled)
            var result: List<User>? = null
            withContext(Dispatchers.IO) {
                result=userRepo.getUsers()

            }
            users.value=result
        }
    }
}