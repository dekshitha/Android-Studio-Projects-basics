package com.example.cc_recycler

import java.util.function.Supplier

data class Fruit(val name:String,val supplier:String)
//no need getter setter in data class
