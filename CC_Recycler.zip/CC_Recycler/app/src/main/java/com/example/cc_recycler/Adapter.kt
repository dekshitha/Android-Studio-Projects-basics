package com.example.cc_recycler

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ExpandableListView.OnChildClickListener
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView

class Adapter(private val fruitsList:List<Fruit>,private val clickListener:(Fruit)->Unit):RecyclerView.Adapter<MyViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val layoutInflater=LayoutInflater.from(parent.context)
        val listItem=layoutInflater.inflate(R.layout.list_item,parent,false)

        return MyViewHolder(listItem)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val fruit=fruitsList[position]
        holder.bind(fruit,clickListener)
    //holder.textView.text="hello $position"
    }

    override fun getItemCount(): Int {
        return fruitsList.size

    }
}

class MyViewHolder(val view: View):RecyclerView.ViewHolder(view){
    fun bind(fruit:Fruit,clickListener:(Fruit)->Unit){
        val textView=view.findViewById<TextView>(R.id.tvName)
        textView.text=fruit.name

        view.setOnClickListener {

            clickListener(fruit)
        }

    }

}