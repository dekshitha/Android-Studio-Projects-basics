package com.example.cc_recycler

import android.annotation.SuppressLint
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    val fruitsList= listOf<Fruit>(
        Fruit("Mango","Joe"),Fruit("Apple","Jim"),Fruit("Strawberry","Roe"),Fruit("Pear","Bob"),Fruit("Lichi","Joe"),Fruit("Kiwi","Joe"),Fruit("Orange","Joe"),Fruit("Guava","Joe")
    )
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val recyclerview=findViewById<RecyclerView>(R.id.recyclerView)
        recyclerview.setBackgroundColor(Color.BLUE)
        recyclerview.layoutManager=LinearLayoutManager(this)

        recyclerview.adapter=Adapter(fruitsList) { selectedItem: Fruit ->
            listItemClicked(selectedItem)
        }


    }

    private fun listItemClicked(fruit: Fruit){
        Toast.makeText(this@MainActivity,"Selected supplier: ${fruit.supplier}", Toast.LENGTH_SHORT).show()

    }
}