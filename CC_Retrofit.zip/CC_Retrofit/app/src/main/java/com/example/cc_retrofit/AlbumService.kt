package com.example.cc_retrofit

import android.provider.MediaStore.Audio.Albums
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query

interface AlbumService {

    @GET("/albums")
    suspend fun getAlbums() :Response<Album>

    @GET("/albums")
    suspend fun getSortedAlbums(@Query("userId") userId:Int) :Response<Album>


    //path parameter /album/3 -> shows det of only id=3
   @GET("/albums/{id}")
    suspend fun getAlbum(@Path(value="id")albumId:Int) : Response<AlbumItem>

    @POST("/albums")
    suspend fun uploadAlbum(@Body album:AlbumItem) : Response<AlbumItem>

}