package com.example.cc_retrofit

class Album : ArrayList<AlbumItem>()